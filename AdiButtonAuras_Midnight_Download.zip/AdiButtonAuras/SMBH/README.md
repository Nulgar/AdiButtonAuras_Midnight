SharedMedia_ButtonHighlight
===========================

Media type and textures for button highlight in LibSharedMeda-3.0.
