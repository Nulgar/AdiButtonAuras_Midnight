# AdiButtonAuras

## [11.0.4](https://github.com/AdiAddons/AdiButtonAuras/tree/11.0.4) (2025-10-31)
[Full Changelog](https://github.com/AdiAddons/AdiButtonAuras/compare/11.0.3...11.0.4) [Previous Releases](https://github.com/AdiAddons/AdiButtonAuras/releases)

- build: set toc for patch 11.2.5  
